# Author: CHIKEB ANAS
# Project: P.L.C.A 1 — NexaGroup Holdings | FY2024

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.series import DataPoint
import csv

wb = openpyxl.Workbook()

# Colors
DARK_BG    = "0D1B2A"
ACCENT     = "1E88E5"
ACCENT2    = "00C9A7"
ACCENT3    = "FF6B35"
HEADER_BG  = "0D1B2A"
SUBHDR_BG  = "1A2F4A"
ROW_ALT    = "EEF4FB"
WHITE      = "FFFFFF"
GOLD       = "F5A623"
RED        = "E53935"
GREEN      = "43A047"
LIGHT_BG   = "F7FAFD"

def hdr(ws, row, col, val, bg=HEADER_BG, fg=WHITE, bold=True, size=11, align="center", wrap=False):
    c = ws.cell(row=row, column=col, value=val)
    c.font = Font(bold=bold, color=fg, size=size, name="Arial")
    c.fill = PatternFill("solid", start_color=bg)
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    return c

def val(ws, row, col, v, fmt=None, bold=False, color="000000", bg=None, align="right"):
    c = ws.cell(row=row, column=col, value=v)
    c.font = Font(bold=bold, color=color, name="Arial", size=10)
    c.alignment = Alignment(horizontal=align, vertical="center")
    if fmt: c.number_format = fmt
    if bg: c.fill = PatternFill("solid", start_color=bg)
    return c

def border_range(ws, min_row, max_row, min_col, max_col, style="thin"):
    thin = Side(style=style)
    for row in ws.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col):
        for cell in row:
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)

# ─── SHEET 1: COVER ───────────────────────────────────────────────
ws_cover = wb.active
ws_cover.title = "📋 Cover"
ws_cover.sheet_view.showGridLines = False
ws_cover.column_dimensions["A"].width = 5
ws_cover.column_dimensions["B"].width = 60
ws_cover.column_dimensions["C"].width = 30

for r in range(1, 35):
    ws_cover.row_dimensions[r].height = 18

# Title block
ws_cover.merge_cells("B2:C2")
c = ws_cover.cell(row=2, column=2, value="P.L.C.A 1")
c.font = Font(bold=True, size=28, color=ACCENT, name="Arial")
c.alignment = Alignment(horizontal="left", vertical="center")

ws_cover.merge_cells("B3:C3")
c = ws_cover.cell(row=3, column=2, value="Profit & Loss — Consolidated Analysis")
c.font = Font(bold=True, size=16, color=DARK_BG, name="Arial")
c.alignment = Alignment(horizontal="left", vertical="center")

ws_cover.merge_cells("B4:C4")
c = ws_cover.cell(row=4, column=2, value="NexaGroup Holdings Ltd. | FY2024 Annual Report")
c.font = Font(bold=False, size=12, color="666666", name="Arial")
c.alignment = Alignment(horizontal="left")

meta = [
    ("Company", "NexaGroup Holdings Ltd."),
    ("Subsidiaries", "NexaCloud SaaS | NexaRetail Pro | NexaAI Solutions"),
    ("Fiscal Year", "January 1, 2024 — December 31, 2024"),
    ("Currency", "USD"),
    ("Prepared By", "Analytics & Finance Division"),
    ("Report Level", "Advanced — Level 3"),
    ("Version", "1.0"),
]
for i, (k, v_) in enumerate(meta):
    r = 7 + i
    c1 = ws_cover.cell(row=r, column=2, value=k)
    c1.font = Font(bold=True, size=10, color=DARK_BG, name="Arial")
    c2 = ws_cover.cell(row=r, column=3, value=v_)
    c2.font = Font(size=10, color="333333", name="Arial")

ws_cover.merge_cells("B16:C16")
c = ws_cover.cell(row=16, column=2, value="CONTENTS")
c.font = Font(bold=True, size=11, color=ACCENT, name="Arial")

sheets_list = [
    ("📊 P&L Summary", "Consolidated Income Statement by Subsidiary"),
    ("📅 Monthly P&L", "Month-by-Month Revenue & Expense Breakdown"),
    ("🏢 Subsidiary Analysis", "Individual Subsidiary Deep-Dive"),
    ("📈 KPI Dashboard", "40+ Financial & SaaS KPIs"),
    ("💰 Cash Flow", "Operating, Investing & Financing Activities"),
    ("📋 General Ledger", "GL Summary by Account"),
]
for i, (sn, desc) in enumerate(sheets_list):
    r = 17 + i
    c1 = ws_cover.cell(row=r, column=2, value=sn)
    c1.font = Font(bold=True, size=10, color=ACCENT, name="Arial")
    c2 = ws_cover.cell(row=r, column=3, value=desc)
    c2.font = Font(size=10, color="555555", name="Arial")

# ─── SHEET 2: P&L SUMMARY ─────────────────────────────────────────
ws_pl = wb.create_sheet("📊 P&L Summary")
ws_pl.sheet_view.showGridLines = False
cols_w = [5, 32, 18, 18, 18, 20, 18]
for i, w in enumerate(cols_w, 1):
    ws_pl.column_dimensions[get_column_letter(i)].width = w
for r in range(1, 60):
    ws_pl.row_dimensions[r].height = 18

ws_pl.merge_cells("B1:G1")
c = ws_pl.cell(row=1, column=2, value="P.L.C.A 1 — CONSOLIDATED P&L STATEMENT  |  FY2024")
c.font = Font(bold=True, size=14, color=WHITE, name="Arial")
c.fill = PatternFill("solid", start_color=HEADER_BG)
c.alignment = Alignment(horizontal="center", vertical="center")
ws_pl.row_dimensions[1].height = 28

headers = ["LINE ITEM", "NEXACLOUD SAAS", "NEXARETAIL PRO", "NEXAAI SOLUTIONS", "CONSOLIDATED", "YoY %"]
for i, h in enumerate(headers):
    c = hdr(ws_pl, 2, 2+i, h, bg=SUBHDR_BG, size=9)

# P&L Line Items with formulas
# Revenue base (per subsidiary per month * 12)
rev = {"SUB001": 2160000, "SUB002": 1440000, "SUB003": 1140000}
cogs_pct = {"SUB001": 0.27, "SUB002": 0.29, "SUB003": 0.25}
salary_pct = {"SUB001": 0.31, "SUB002": 0.29, "SUB003": 0.33}
mktg_pct = {"SUB001": 0.11, "SUB002": 0.12, "SUB003": 0.09}
rnd_pct = {"SUB001": 0.10, "SUB002": 0.06, "SUB003": 0.08}
ga_pct = {"SUB001": 0.06, "SUB002": 0.05, "SUB003": 0.07}
depr_pct = 0.03
int_pct = 0.015
prior_rev = {"SUB001": 1850000, "SUB002": 1280000, "SUB003": 920000}

subs = ["SUB001","SUB002","SUB003"]
sub_cols = {"SUB001":3,"SUB002":4,"SUB003":5}

line_items = []
def add_line(label, vals, fmt='#,##0', bold=False, bg=None, is_formula=False, pct_col=True):
    line_items.append((label, vals, fmt, bold, bg, is_formula, pct_col))

r_saas = round(rev["SUB001"] * 1.168)
r_ret  = round(rev["SUB002"] * 1.125)
r_ai   = round(rev["SUB003"] * 1.239)

add_line("REVENUE", None, '#,##0', True, ACCENT)
add_line("  Gross Revenue", [r_saas, r_ret, r_ai], '#,##0', False, None)
add_line("  Discounts & Returns", [-round(r_saas*0.03),-round(r_ret*0.025),-round(r_ai*0.02)], '#,##0', False, None)
add_line("NET REVENUE", [round(r_saas*0.97),round(r_ret*0.975),round(r_ai*0.98)], '#,##0', True, ROW_ALT)
add_line("", [], '', False, None)
add_line("COST OF REVENUE", None, '', True, ACCENT)
add_line("  COGS", [-round(r_saas*0.97*cogs_pct["SUB001"]),-round(r_ret*0.975*cogs_pct["SUB002"]),-round(r_ai*0.98*cogs_pct["SUB003"])], '#,##0', False, None)
add_line("GROSS PROFIT", [round(r_saas*0.97*(1-cogs_pct["SUB001"])),round(r_ret*0.975*(1-cogs_pct["SUB002"])),round(r_ai*0.98*(1-cogs_pct["SUB003"]))], '#,##0', True, ROW_ALT)
add_line("Gross Margin %", [round(1-cogs_pct["SUB001"],3),round(1-cogs_pct["SUB002"],3),round(1-cogs_pct["SUB003"],3)], '0.0%', False, LIGHT_BG)
add_line("", [], '', False, None)
add_line("OPERATING EXPENSES", None, '', True, ACCENT)
add_line("  Salaries & Wages", [-round(r_saas*0.97*salary_pct["SUB001"]),-round(r_ret*0.975*salary_pct["SUB002"]),-round(r_ai*0.98*salary_pct["SUB003"])], '#,##0', False, None)
add_line("  Marketing & Growth", [-round(r_saas*0.97*mktg_pct["SUB001"]),-round(r_ret*0.975*mktg_pct["SUB002"]),-round(r_ai*0.98*mktg_pct["SUB003"])], '#,##0', False, None)
add_line("  Research & Development", [-round(r_saas*0.97*rnd_pct["SUB001"]),-round(r_ret*0.975*rnd_pct["SUB002"]),-round(r_ai*0.98*rnd_pct["SUB003"])], '#,##0', False, None)
add_line("  General & Administrative", [-round(r_saas*0.97*ga_pct["SUB001"]),-round(r_ret*0.975*ga_pct["SUB002"]),-round(r_ai*0.98*ga_pct["SUB003"])], '#,##0', False, None)
add_line("  Depreciation & Amortization", [-round(r_saas*0.97*depr_pct),-round(r_ret*0.975*depr_pct),-round(r_ai*0.98*depr_pct)], '#,##0', False, None)
ebit = {
    "SUB001": round(r_saas*0.97*(1-cogs_pct["SUB001"]-salary_pct["SUB001"]-mktg_pct["SUB001"]-rnd_pct["SUB001"]-ga_pct["SUB001"]-depr_pct)),
    "SUB002": round(r_ret*0.975*(1-cogs_pct["SUB002"]-salary_pct["SUB002"]-mktg_pct["SUB002"]-rnd_pct["SUB002"]-ga_pct["SUB002"]-depr_pct)),
    "SUB003": round(r_ai*0.98*(1-cogs_pct["SUB003"]-salary_pct["SUB003"]-mktg_pct["SUB003"]-rnd_pct["SUB003"]-ga_pct["SUB003"]-depr_pct)),
}
add_line("EBIT", [ebit["SUB001"],ebit["SUB002"],ebit["SUB003"]], '#,##0', True, ROW_ALT)
add_line("EBIT Margin %", [round(ebit["SUB001"]/(r_saas*0.97),3),round(ebit["SUB002"]/(r_ret*0.975),3),round(ebit["SUB003"]/(r_ai*0.98),3)], '0.0%', False, LIGHT_BG)
add_line("", [], '', False, None)
ebitda = {k: ebit[k]+round({"SUB001":r_saas,"SUB002":r_ret,"SUB003":r_ai}[k]*depr_pct) for k in subs}
add_line("EBITDA", [ebitda["SUB001"],ebitda["SUB002"],ebitda["SUB003"]], '#,##0', True, ROW_ALT)
add_line("EBITDA Margin %", [round(ebitda["SUB001"]/(r_saas*0.97),3),round(ebitda["SUB002"]/(r_ret*0.975),3),round(ebitda["SUB003"]/(r_ai*0.98),3)], '0.0%', False, LIGHT_BG)
add_line("", [], '', False, None)
add_line("BELOW THE LINE", None, '', True, ACCENT)
int_exp = {k: -round({"SUB001":r_saas,"SUB002":r_ret,"SUB003":r_ai}[k]*int_pct) for k in subs}
add_line("  Interest Expense", [int_exp["SUB001"],int_exp["SUB002"],int_exp["SUB003"]], '#,##0', False, None)
ebt = {k: ebit[k]+int_exp[k] for k in subs}
add_line("EBT (Earnings Before Tax)", [ebt["SUB001"],ebt["SUB002"],ebt["SUB003"]], '#,##0', True, ROW_ALT)
tax = {k: -round(max(ebt[k],0)*0.21) for k in subs}
add_line("  Income Tax (21%)", [tax["SUB001"],tax["SUB002"],tax["SUB003"]], '#,##0', False, None)
net_income = {k: ebt[k]+tax[k] for k in subs}
add_line("NET INCOME", [net_income["SUB001"],net_income["SUB002"],net_income["SUB003"]], '#,##0', True, ACCENT)
ni_margin = {k: round(net_income[k]/{"SUB001":r_saas*0.97,"SUB002":r_ret*0.975,"SUB003":r_ai*0.98}[k],3) for k in subs}
add_line("Net Margin %", [ni_margin["SUB001"],ni_margin["SUB002"],ni_margin["SUB003"]], '0.0%', False, LIGHT_BG)

row = 3
for (label, vals, fmt, bold, bg, is_formula, pct_col) in line_items:
    bg_use = bg if bg else WHITE
    if not vals:
        c = ws_pl.cell(row=row, column=2, value=label)
        c.font = Font(bold=True, color=WHITE if bg==ACCENT else DARK_BG, size=10, name="Arial")
        c.fill = PatternFill("solid", start_color=ACCENT if bg==ACCENT else WHITE)
        ws_pl.merge_cells(f"B{row}:G{row}")
        c.alignment = Alignment(horizontal="left", vertical="center")
        row += 1
        continue
    c = ws_pl.cell(row=row, column=2, value=label)
    c.font = Font(bold=bold, color=DARK_BG, size=10, name="Arial")
    c.fill = PatternFill("solid", start_color=bg_use if bg_use!=ACCENT else ROW_ALT)
    c.alignment = Alignment(horizontal="left", vertical="center")

    total = 0
    for j, sub in enumerate(subs):
        col = 3 + j
        v_ = vals[j] if j < len(vals) else 0
        c2 = ws_pl.cell(row=row, column=col, value=v_)
        c2.font = Font(bold=bold, color=RED if v_<0 else DARK_BG, size=10, name="Arial")
        c2.fill = PatternFill("solid", start_color=bg_use if bg_use!=ACCENT else ROW_ALT)
        c2.alignment = Alignment(horizontal="right", vertical="center")
        c2.number_format = fmt
        if fmt != '0.0%': total += v_
    
    # Consolidated
    if fmt == '0.0%':
        avg_val = round(sum(vals)/3, 3)
        c3 = ws_pl.cell(row=row, column=6, value=avg_val)
        c3.number_format = '0.0%'
        c3.font = Font(bold=bold, size=10, name="Arial")
        c3.fill = PatternFill("solid", start_color=bg_use if bg_use!=ACCENT else ROW_ALT)
        c3.alignment = Alignment(horizontal="right", vertical="center")
    else:
        c3 = ws_pl.cell(row=row, column=6, value=f"=C{row}+D{row}+E{row}")
        c3.number_format = fmt
        c3.font = Font(bold=bold, size=10, name="Arial", color=RED if total<0 else DARK_BG)
        c3.fill = PatternFill("solid", start_color=bg_use if bg_use!=ACCENT else ROW_ALT)
        c3.alignment = Alignment(horizontal="right", vertical="center")
    row += 1

thin = Side(style="thin")
for r_ in range(2, row):
    for col_ in range(2, 8):
        c_ = ws_pl.cell(r_, col_)
        c_.border = Border(left=thin, right=thin, top=thin, bottom=thin)

# ─── SHEET 3: MONTHLY P&L ─────────────────────────────────────────
ws_mo = wb.create_sheet("📅 Monthly P&L")
ws_mo.sheet_view.showGridLines = False
months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
month_rev = {
    "NexaCloud": [195000,188000,210000,225000,218000,240000,255000,249000,262000,278000,285000,298000],
    "NexaRetail": [118000,125000,135000,142000,149000,155000,162000,158000,168000,175000,182000,195000],
    "NexaAI":     [85000,90000,98000,105000,112000,118000,122000,128000,134000,140000,148000,155000],
}

ws_mo.column_dimensions["A"].width = 4
ws_mo.column_dimensions["B"].width = 28
for i, m in enumerate(months):
    ws_mo.column_dimensions[get_column_letter(3+i)].width = 12
ws_mo.column_dimensions[get_column_letter(15)].width = 14
ws_mo.column_dimensions[get_column_letter(16)].width = 10

ws_mo.merge_cells("B1:P1")
c = ws_mo.cell(1,2,"P.L.C.A 1 — MONTHLY REVENUE & EXPENSE ANALYSIS  |  FY2024")
c.font = Font(bold=True,size=13,color=WHITE,name="Arial")
c.fill = PatternFill("solid",start_color=HEADER_BG)
c.alignment = Alignment(horizontal="center",vertical="center")
ws_mo.row_dimensions[1].height = 26

hdr(ws_mo,2,2,"METRIC", bg=SUBHDR_BG, align="left")
for i,m in enumerate(months):
    hdr(ws_mo,2,3+i,m,bg=SUBHDR_BG,size=9)
hdr(ws_mo,2,15,"TOTAL",bg=ACCENT,size=9)
hdr(ws_mo,2,16,"GROWTH",bg=ACCENT,size=9)

sub_data = [
    ("NexaCloud SaaS Revenue", "NexaCloud", LIGHT_BG),
    ("NexaRetail Revenue", "NexaRetail", WHITE),
    ("NexaAI Revenue", "NexaAI", LIGHT_BG),
]
row = 3
for label, key, bg_ in sub_data:
    c = ws_mo.cell(row,2,label)
    c.font = Font(bold=True,size=10,name="Arial")
    c.fill = PatternFill("solid",start_color=bg_)
    c.alignment = Alignment(horizontal="left",vertical="center")
    for i,v_ in enumerate(month_rev[key]):
        c2 = ws_mo.cell(row,3+i,v_)
        c2.number_format = '#,##0'
        c2.font = Font(size=10,name="Arial")
        c2.fill = PatternFill("solid",start_color=bg_)
        c2.alignment = Alignment(horizontal="right")
    total_c = ws_mo.cell(row,15,f"=SUM(C{row}:N{row})")
    total_c.number_format = '#,##0'
    total_c.font = Font(bold=True,size=10,name="Arial",color=WHITE)
    total_c.fill = PatternFill("solid",start_color=ACCENT)
    total_c.alignment = Alignment(horizontal="right")
    # Growth vs prior year (approximate)
    prior = {"NexaCloud":1850000,"NexaRetail":1280000,"NexaAI":920000}[key]
    total_val = sum(month_rev[key])
    growth_c = ws_mo.cell(row,16,round((total_val-prior)/prior,3))
    growth_c.number_format = '0.0%'
    growth_c.font = Font(bold=True,size=10,name="Arial",color=WHITE)
    growth_c.fill = PatternFill("solid",start_color=GREEN)
    growth_c.alignment = Alignment(horizontal="center")
    row += 1

# Consolidated
c = ws_mo.cell(row,2,"CONSOLIDATED REVENUE")
c.font = Font(bold=True,size=10,name="Arial",color=WHITE)
c.fill = PatternFill("solid",start_color=DARK_BG)
c.alignment = Alignment(horizontal="left")
for i in range(12):
    col_ = 3+i
    v_ = ws_mo.cell(row,col_,f"=C{row-3}+C{row-2}+C{row-1}".replace("C",get_column_letter(col_)))
    v_.number_format = '#,##0'
    v_.font = Font(bold=True,size=10,name="Arial",color=WHITE)
    v_.fill = PatternFill("solid",start_color=DARK_BG)
    v_.alignment = Alignment(horizontal="right")
total_c2 = ws_mo.cell(row,15,f"=SUM(C{row}:N{row})")
total_c2.number_format = '#,##0'
total_c2.font = Font(bold=True,color=WHITE,name="Arial")
total_c2.fill = PatternFill("solid",start_color=DARK_BG)
total_c2.alignment = Alignment(horizontal="right")
row += 1

# Add chart
chart = LineChart()
chart.title = "Monthly Revenue by Subsidiary — FY2024"
chart.style = 10
chart.y_axis.title = "USD"
chart.x_axis.title = "Month"
chart.width = 28
chart.height = 14

for i, (label, key, _) in enumerate(sub_data):
    data_ref = Reference(ws_mo, min_col=3, max_col=14, min_row=3+i, max_row=3+i)
    from openpyxl.chart import Series
    s = Series(data_ref, title=label)
    chart.append(s)

cats = Reference(ws_mo, min_col=3, max_col=14, min_row=2)
chart.set_categories(cats)
ws_mo.add_chart(chart, "B10")

# ─── SHEET 4: KPI DASHBOARD ─────────────────────────────────────────
ws_kpi = wb.create_sheet("📈 KPI Dashboard")
ws_kpi.sheet_view.showGridLines = False
ws_kpi.column_dimensions["A"].width = 4
for c_ in ["B","C","D","E","F","G","H"]:
    ws_kpi.column_dimensions[c_].width = 20

ws_kpi.merge_cells("B1:H1")
c = ws_kpi.cell(1,2,"P.L.C.A 1 — KPI DASHBOARD  |  NEXAGROUP HOLDINGS  |  FY2024")
c.font = Font(bold=True,size=13,color=WHITE,name="Arial")
c.fill = PatternFill("solid",start_color=HEADER_BG)
c.alignment = Alignment(horizontal="center",vertical="center")
ws_kpi.row_dimensions[1].height = 26

kpi_sections = [
    ("💰 FINANCIAL KPIs", [
        ("Total Revenue (USD)", "$4,740,000", "+17.3%", GREEN),
        ("Net Revenue", "$4,620,150", "+16.8%", GREEN),
        ("Gross Profit", "$3,322,308", "+18.1%", GREEN),
        ("EBITDA", "$897,440", "+22.5%", GREEN),
        ("Net Income", "$628,214", "+19.7%", GREEN),
        ("Gross Margin", "71.9%", "+1.2pp", GREEN),
        ("EBITDA Margin", "19.4%", "+0.8pp", GREEN),
        ("Net Margin", "13.6%", "+0.4pp", GREEN),
    ]),
    ("📊 SAAS KPIs (NexaCloud)", [
        ("ARR (Annual Recurring Revenue)", "$2,523,000", "+16.8%", GREEN),
        ("MRR (Monthly Recurring Revenue)", "$210,250", "+16.8%", GREEN),
        ("Active Customers", "2,847", "+23.1%", GREEN),
        ("Churn Rate (Annual)", "4.2%", "-1.1pp", GREEN),
        ("NRR (Net Revenue Retention)", "118%", "+3pp", GREEN),
        ("CAC (Customer Acq. Cost)", "$342", "-8.2%", GREEN),
        ("LTV (Customer Lifetime Value)", "$8,190", "+12.4%", GREEN),
        ("LTV:CAC Ratio", "23.9x", "+22.6%", GREEN),
    ]),
    ("📦 SUBSIDIARY KPIs", [
        ("NexaCloud Revenue", "$2,523,000", "+16.8%", GREEN),
        ("NexaRetail Revenue", "$1,408,500", "+10.0%", GREEN),
        ("NexaAI Revenue", "$1,413,000", "+53.6%", ACCENT),
        ("NexaCloud EBITDA Margin", "21.3%", "+1.5pp", GREEN),
        ("NexaRetail EBITDA Margin", "17.1%", "-0.4pp", RED),
        ("NexaAI EBITDA Margin", "24.8%", "+3.2pp", ACCENT2),
        ("NexaCloud Headcount", "87", "+12", GREEN),
        ("NexaAI Headcount", "34", "+9", GREEN),
    ]),
    ("📣 MARKETING KPIs", [
        ("Total Marketing Spend", "$496,200", "+15.2%", GREEN),
        ("Blended CAC", "$342", "-8.2%", GREEN),
        ("Lead-to-Close Rate", "22.4%", "+3.1pp", GREEN),
        ("Marketing ROI", "8.56x", "+0.7x", GREEN),
        ("New Customers (FY2024)", "1,452", "+28.3%", GREEN),
        ("Organic Traffic Growth", "34.5%", "N/A", ACCENT),
        ("Email Open Rate", "28.7%", "+2.1pp", GREEN),
        ("Demo Conversion Rate", "18.3%", "+1.4pp", GREEN),
    ]),
]

row = 3
for (section_title, kpis) in kpi_sections:
    ws_kpi.merge_cells(f"B{row}:H{row}")
    c = ws_kpi.cell(row,2,section_title)
    c.font = Font(bold=True,size=11,color=WHITE,name="Arial")
    c.fill = PatternFill("solid",start_color=SUBHDR_BG)
    c.alignment = Alignment(horizontal="left",vertical="center")
    ws_kpi.row_dimensions[row].height = 20
    row += 1
    hdr(ws_kpi,row,2,"KPI",bg=DARK_BG,align="left",size=9)
    hdr(ws_kpi,row,3,"FY2024 VALUE",bg=DARK_BG,size=9)
    hdr(ws_kpi,row,4,"VS PRIOR YEAR",bg=DARK_BG,size=9)
    row += 1
    for i,(kpi_name,kpi_val,change,color) in enumerate(kpis):
        bg_ = ROW_ALT if i%2==0 else WHITE
        c1 = ws_kpi.cell(row,2,kpi_name)
        c1.font = Font(size=10,name="Arial",bold=False)
        c1.fill = PatternFill("solid",start_color=bg_)
        c1.alignment = Alignment(horizontal="left",vertical="center")
        c2 = ws_kpi.cell(row,3,kpi_val)
        c2.font = Font(size=10,name="Arial",bold=True,color=DARK_BG)
        c2.fill = PatternFill("solid",start_color=bg_)
        c2.alignment = Alignment(horizontal="right")
        c3 = ws_kpi.cell(row,4,change)
        c3.font = Font(size=10,name="Arial",bold=True,color=color)
        c3.fill = PatternFill("solid",start_color=bg_)
        c3.alignment = Alignment(horizontal="center")
        row += 1
    row += 1

# ─── SHEET 5: CASH FLOW ─────────────────────────────────────────
ws_cf = wb.create_sheet("💰 Cash Flow")
ws_cf.sheet_view.showGridLines = False
ws_cf.column_dimensions["A"].width = 4
ws_cf.column_dimensions["B"].width = 38
ws_cf.column_dimensions["C"].width = 18
ws_cf.column_dimensions["D"].width = 18
ws_cf.column_dimensions["E"].width = 18

ws_cf.merge_cells("B1:E1")
c = ws_cf.cell(1,2,"P.L.C.A 1 — CONSOLIDATED CASH FLOW STATEMENT  |  FY2024")
c.font = Font(bold=True,size=13,color=WHITE,name="Arial")
c.fill = PatternFill("solid",start_color=HEADER_BG)
c.alignment = Alignment(horizontal="center",vertical="center")
ws_cf.row_dimensions[1].height = 26

hdr(ws_cf,2,2,"LINE ITEM",bg=SUBHDR_BG,align="left")
hdr(ws_cf,2,3,"H1 2024",bg=SUBHDR_BG)
hdr(ws_cf,2,4,"H2 2024",bg=SUBHDR_BG)
hdr(ws_cf,2,5,"FY 2024",bg=SUBHDR_BG)

cf_data = [
    ("OPERATING ACTIVITIES", None, None, None, True, ACCENT),
    ("  Net Income", 285000, 343214, None, False, None),
    ("  Depreciation & Amortization", 67200, 74800, None, False, None),
    ("  Changes in Working Capital", -24500, -18200, None, False, None),
    ("  Accounts Receivable Changes", -85000, -62000, None, False, None),
    ("  Accounts Payable Changes", 32000, 28500, None, False, None),
    ("CASH FROM OPERATIONS", 274700, 366314, None, True, ROW_ALT),
    ("", None, None, None, False, None),
    ("INVESTING ACTIVITIES", None, None, None, True, ACCENT),
    ("  Capital Expenditures (CapEx)", -145000, -168000, None, False, None),
    ("  Software Development Capitalized", -82000, -95000, None, False, None),
    ("  Acquisitions / Investments", 0, -150000, None, False, None),
    ("CASH FROM INVESTING", -227000, -413000, None, True, ROW_ALT),
    ("", None, None, None, False, None),
    ("FINANCING ACTIVITIES", None, None, None, True, ACCENT),
    ("  Loan Drawdown", 0, 200000, None, False, None),
    ("  Loan Repayments", -55000, -55000, None, False, None),
    ("  Equity Raised", 500000, 0, None, False, None),
    ("  Dividends Paid", -50000, -50000, None, False, None),
    ("CASH FROM FINANCING", 395000, 95000, None, True, ROW_ALT),
    ("", None, None, None, False, None),
    ("NET CASH MOVEMENT", 442700, 48314, None, True, DARK_BG),
    ("Opening Cash Balance", 380000, 822700, None, False, LIGHT_BG),
    ("CLOSING CASH BALANCE", 822700, 871014, None, True, ACCENT2),
]

for r_, (label, h1, h2, _, bold, bg) in enumerate(cf_data):
    rr = 3 + r_
    bg_use = bg if bg else WHITE
    c1 = ws_cf.cell(rr,2,label)
    c1.font = Font(bold=bold,size=10,name="Arial",color=WHITE if bg in [ACCENT,DARK_BG] else DARK_BG)
    c1.fill = PatternFill("solid",start_color=bg_use if bg_use else WHITE)
    c1.alignment = Alignment(horizontal="left",vertical="center")
    if h1 is not None:
        c2 = ws_cf.cell(rr,3,h1)
        c2.number_format = '#,##0'
        c2.font = Font(bold=bold,size=10,name="Arial",color=WHITE if bg in [ACCENT,DARK_BG,ACCENT2] else (RED if h1<0 else DARK_BG))
        c2.fill = PatternFill("solid",start_color=bg_use if bg_use else WHITE)
        c2.alignment = Alignment(horizontal="right")
        c3 = ws_cf.cell(rr,4,h2)
        c3.number_format = '#,##0'
        c3.font = Font(bold=bold,size=10,name="Arial",color=WHITE if bg in [ACCENT,DARK_BG,ACCENT2] else (RED if h2<0 else DARK_BG))
        c3.fill = PatternFill("solid",start_color=bg_use if bg_use else WHITE)
        c3.alignment = Alignment(horizontal="right")
        c4 = ws_cf.cell(rr,5,f"=C{rr}+D{rr}")
        c4.number_format = '#,##0'
        c4.font = Font(bold=bold,size=10,name="Arial",color=WHITE if bg in [ACCENT,DARK_BG,ACCENT2] else DARK_BG)
        c4.fill = PatternFill("solid",start_color=bg_use if bg_use else WHITE)
        c4.alignment = Alignment(horizontal="right")

# ─── SHEET 6: GL SUMMARY ─────────────────────────────────────────
ws_gl = wb.create_sheet("📋 General Ledger")
ws_gl.sheet_view.showGridLines = False
ws_gl.column_dimensions["A"].width = 4
ws_gl.column_dimensions["B"].width = 12
ws_gl.column_dimensions["C"].width = 30
ws_gl.column_dimensions["D"].width = 16
ws_gl.column_dimensions["E"].width = 14
ws_gl.column_dimensions["F"].width = 14
ws_gl.column_dimensions["G"].width = 14
ws_gl.column_dimensions["H"].width = 14

ws_gl.merge_cells("B1:H1")
c = ws_gl.cell(1,2,"P.L.C.A 1 — GENERAL LEDGER SUMMARY  |  FY2024")
c.font = Font(bold=True,size=13,color=WHITE,name="Arial")
c.fill = PatternFill("solid",start_color=HEADER_BG)
c.alignment = Alignment(horizontal="center",vertical="center")
ws_gl.row_dimensions[1].height = 26

for ci,h in enumerate(["ACCT CODE","ACCOUNT NAME","TYPE","Q1","Q2","Q3","Q4"]):
    hdr(ws_gl,2,2+ci,h,bg=SUBHDR_BG,size=9,align="left" if ci<2 else "right")

gl_accounts = [
    ("4000","Revenue","Income",590000,1180000,1770000,2360000),
    ("4100","SaaS Revenue","Income",480000,960000,1440000,1920000),
    ("4200","Services Revenue","Income",285000,570000,855000,1140000),
    ("5000","COGS","Expense",168000,336000,504000,672000),
    ("5100","Hosting & Infra","Expense",45000,90000,135000,180000),
    ("6000","Salaries & Wages","Expense",318000,636000,954000,1272000),
    ("6100","Marketing","Expense",88000,176000,264000,352000),
    ("6200","R&D","Expense",72000,144000,216000,288000),
    ("6300","G&A","Expense",42000,84000,126000,168000),
    ("6400","Depreciation","Expense",35000,70000,105000,140000),
    ("7000","Interest Expense","Expense",17000,34000,51000,68000),
    ("1000","Cash & Equivalents","Asset",822700,831000,856000,871014),
    ("1100","Accounts Receivable","Asset",215000,242000,278000,310000),
    ("2000","Accounts Payable","Liability",98000,92000,105000,118000),
    ("3000","Retained Earnings","Equity",140000,320000,498000,628214),
]
for i,(ac,an,at,q1,q2,q3,q4) in enumerate(gl_accounts):
    rr = 3+i
    bg_ = ROW_ALT if i%2==0 else WHITE
    ws_gl.cell(rr,2,ac).fill = PatternFill("solid",start_color=bg_)
    ws_gl.cell(rr,2,ac).font = Font(size=10,name="Arial")
    ws_gl.cell(rr,3,an).fill = PatternFill("solid",start_color=bg_)
    ws_gl.cell(rr,3,an).font = Font(bold=True,size=10,name="Arial")
    ws_gl.cell(rr,4,at).fill = PatternFill("solid",start_color=bg_)
    ws_gl.cell(rr,4,at).font = Font(size=10,name="Arial",
        color=GREEN if at=="Income" else RED if at=="Expense" else ACCENT)
    for ci,qv in enumerate([q1,q2,q3,q4]):
        c_ = ws_gl.cell(rr,5+ci,qv)
        c_.number_format = '#,##0'
        c_.font = Font(size=10,name="Arial")
        c_.fill = PatternFill("solid",start_color=bg_)
        c_.alignment = Alignment(horizontal="right")

border_range(ws_gl,2,3+len(gl_accounts),2,8)

path = "/home/claude/PLCA1/reports/PLCA1_Financial_Model.xlsx"
wb.save(path)
print("Excel saved:", path)
