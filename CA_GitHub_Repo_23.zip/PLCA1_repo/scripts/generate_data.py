# Author: CHIKEB ANAS
# Project: P.L.C.A 1 — NexaGroup Holdings | FY2024

import csv, json, random
from datetime import date, timedelta

random.seed(42)

subsidiaries = [
    ("SUB001", "NexaCloud SaaS", "SaaS", "USD"),
    ("SUB002", "NexaRetail Pro", "E-Commerce", "USD"),
    ("SUB003", "NexaAI Solutions", "AI Consulting", "USD"),
]

departments = ["Sales", "Engineering", "Marketing", "Finance", "Operations", "HR"]

products = {
    "SUB001": [("PRD-CS-001","CloudBase Plan",199),("PRD-CS-002","CloudPro Plan",499),("PRD-CS-003","CloudEnterprise",1299),("PRD-CS-004","API Add-on",149)],
    "SUB002": [("PRD-RT-001","Storefront Starter",299),("PRD-RT-002","Storefront Pro",799),("PRD-RT-003","Analytics Suite",399),("PRD-RT-004","POS Integration",599)],
    "SUB003": [("PRD-AI-001","AI Audit",3500),("PRD-AI-002","ML Pipeline Build",8500),("PRD-AI-003","Data Strategy",5000),("PRD-AI-004","BI Implementation",7000)],
}

customers = []
for i in range(1, 121):
    sub = random.choice(subsidiaries)
    cid = f"CUS-{i:04d}"
    cname = random.choice(["Apex Corp","BlueStar Ltd","Citadel Inc","DeltaGroup","Echo Systems",
                            "Fusion Works","GreenTech","HorizonAI","InnovateCo","Jupiter Labs",
                            "Kinetic Data","Lunar Media","Monarch SaaS","Nexus Digital","Orbit Cloud",
                            "Pinnacle ERP","Quantum AI","Radius Tech","Spark Analytics","TrueData Co",
                            "Ultratech","Vertex Systems","Waveform Inc","Xenon Cloud","YieldBase"])
    customers.append({"customer_id": cid, "customer_name": cname + f" {i}", "subsidiary_id": sub[0],
                       "segment": random.choice(["SMB","Mid-Market","Enterprise"]),
                       "country": random.choice(["USA","UK","France","Germany","UAE","Canada","Morocco","Spain"]),
                       "acquisition_date": str(date(2022, random.randint(1,12), random.randint(1,28))),
                       "status": random.choice(["Active","Active","Active","Churned"])})

with open("/home/claude/PLCA1/data/customers.csv","w",newline="") as f:
    w = csv.DictWriter(f, fieldnames=customers[0].keys())
    w.writeheader(); w.writerows(customers)

# Transactions
txns = []
txn_id = 1
start_date = date(2024, 1, 1)
for day_offset in range(366):
    d = start_date + timedelta(days=day_offset)
    if d > date(2024, 12, 31): break
    n_txns = random.randint(3, 12)
    for _ in range(n_txns):
        sub = random.choice(subsidiaries)
        prods = products[sub[0]]
        prod = random.choice(prods)
        qty = random.randint(1, 5)
        unit_price = prod[2] * random.uniform(0.9, 1.1)
        discount = random.choice([0, 0, 0, 0.05, 0.10, 0.15])
        amount = round(qty * unit_price * (1 - discount), 2)
        cust = random.choice([c for c in customers if c["subsidiary_id"] == sub[0]])
        txns.append({
            "transaction_id": f"TXN-{txn_id:06d}",
            "date": str(d),
            "month": d.month,
            "quarter": (d.month - 1) // 3 + 1,
            "year": d.year,
            "subsidiary_id": sub[0],
            "subsidiary_name": sub[1],
            "customer_id": cust["customer_id"],
            "product_id": prod[0],
            "product_name": prod[1],
            "category": sub[2],
            "department": random.choice(departments[:2]),
            "quantity": qty,
            "unit_price": round(unit_price, 2),
            "discount_rate": discount,
            "gross_amount": round(qty * unit_price, 2),
            "net_amount": amount,
            "currency": sub[3],
            "payment_method": random.choice(["Card","Wire","ACH","Invoice"]),
            "status": random.choice(["Completed","Completed","Completed","Pending","Refunded"])
        })
        txn_id += 1

with open("/home/claude/PLCA1/data/transactions.csv","w",newline="") as f:
    w = csv.DictWriter(f, fieldnames=txns[0].keys())
    w.writeheader(); w.writerows(txns)

# General Ledger
gl_accounts = [
    ("4000","Revenue","Income"),("4100","SaaS Revenue","Income"),("4200","Services Revenue","Income"),
    ("4300","Product Revenue","Income"),("5000","COGS","Expense"),("5100","Hosting & Infrastructure","Expense"),
    ("5200","Direct Labor","Expense"),("6000","Salaries & Wages","Expense"),("6100","Marketing","Expense"),
    ("6200","R&D","Expense"),("6300","G&A","Expense"),("6400","Depreciation","Expense"),
    ("7000","Interest Expense","Expense"),("1000","Cash & Equivalents","Asset"),("1100","Accounts Receivable","Asset"),
    ("2000","Accounts Payable","Liability"),("3000","Retained Earnings","Equity"),
]

gl_entries = []
gl_id = 1
for month in range(1, 13):
    d = date(2024, month, random.randint(25, 28))
    for sub in subsidiaries:
        base_rev = {"SUB001": 180000, "SUB002": 120000, "SUB003": 95000}[sub[0]]
        rev = round(base_rev * random.uniform(0.85, 1.2), 2)
        cogs = round(rev * random.uniform(0.22, 0.32), 2)
        salaries = round(rev * random.uniform(0.28, 0.35), 2)
        mktg = round(rev * random.uniform(0.08, 0.14), 2)
        rnd = round(rev * random.uniform(0.06, 0.12), 2)
        ga = round(rev * random.uniform(0.04, 0.08), 2)
        depr = round(rev * 0.03, 2)
        interest = round(rev * 0.015, 2)
        ref = f"JE-{gl_id:05d}"
        entries = [
            ("1000","Cash & Equivalents","Asset","Debit",rev,"Monthly Revenue Receipt"),
            ("4000","Revenue","Income","Credit",rev,"Monthly Revenue Recognition"),
            ("5000","COGS","Expense","Debit",cogs,"Cost of Revenue"),
            ("1000","Cash & Equivalents","Asset","Credit",cogs,"COGS Payment"),
            ("6000","Salaries & Wages","Expense","Debit",salaries,"Payroll"),
            ("1000","Cash & Equivalents","Asset","Credit",salaries,"Payroll Disbursement"),
            ("6100","Marketing","Expense","Debit",mktg,"Marketing Spend"),
            ("1000","Cash & Equivalents","Asset","Credit",mktg,"Marketing Payment"),
            ("6200","R&D","Expense","Debit",rnd,"R&D Expense"),
            ("1000","Cash & Equivalents","Asset","Credit",rnd,"R&D Payment"),
            ("6300","G&A","Expense","Debit",ga,"G&A Expense"),
            ("1000","Cash & Equivalents","Asset","Credit",ga,"G&A Payment"),
            ("6400","Depreciation","Expense","Debit",depr,"Monthly Depreciation"),
            ("7000","Interest Expense","Expense","Debit",interest,"Loan Interest"),
        ]
        for acc_code, acc_name, acc_type, dr_cr, amt, desc in entries:
            gl_entries.append({
                "entry_id": f"GL-{gl_id:06d}",
                "journal_ref": ref,
                "date": str(d),
                "month": month,
                "quarter": (month - 1) // 3 + 1,
                "year": 2024,
                "subsidiary_id": sub[0],
                "subsidiary_name": sub[1],
                "account_code": acc_code,
                "account_name": acc_name,
                "account_type": acc_type,
                "debit_credit": dr_cr,
                "amount": amt,
                "description": desc,
                "department": random.choice(departments),
                "posted_by": random.choice(["jsmith","klee","amorris","bwilson","cdubois"]),
                "approved": True
            })
            gl_id += 1

with open("/home/claude/PLCA1/data/general_ledger.csv","w",newline="") as f:
    w = csv.DictWriter(f, fieldnames=gl_entries[0].keys())
    w.writeheader(); w.writerows(gl_entries)

print(f"Transactions: {len(txns)}")
print(f"GL Entries: {len(gl_entries)}")
print(f"Customers: {len(customers)}")
