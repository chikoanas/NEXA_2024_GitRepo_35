-- ============================================================
-- P.L.C.A 1 — PROFIT & LOSS CONSOLIDATED ANALYSIS
-- NexaGroup Holdings Ltd. | FY2024
-- PostgreSQL Schema + Analytics Queries
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- SCHEMA: nexagroup
-- ────────────────────────────────────────────────────────────
CREATE SCHEMA IF NOT EXISTS nexagroup;
SET search_path TO nexagroup;

-- ────────────────────────────────────────────────────────────
-- DIM: Subsidiaries
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dim_subsidiary (
    subsidiary_id   VARCHAR(10)  PRIMARY KEY,
    subsidiary_name VARCHAR(100) NOT NULL,
    category        VARCHAR(50)  NOT NULL,
    currency        CHAR(3)      DEFAULT 'USD',
    country         VARCHAR(50),
    founded_year    INT,
    headcount       INT,
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO dim_subsidiary VALUES
  ('SUB001', 'NexaCloud SaaS',    'SaaS',          'USD', 'USA',     2019, 87, NOW()),
  ('SUB002', 'NexaRetail Pro',    'E-Commerce',    'USD', 'USA',     2020, 52, NOW()),
  ('SUB003', 'NexaAI Solutions',  'AI Consulting', 'USD', 'UK',      2021, 34, NOW());

-- ────────────────────────────────────────────────────────────
-- DIM: Customers
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dim_customer (
    customer_id      VARCHAR(15) PRIMARY KEY,
    customer_name    VARCHAR(150) NOT NULL,
    subsidiary_id    VARCHAR(10)  REFERENCES dim_subsidiary(subsidiary_id),
    segment          VARCHAR(30)  CHECK (segment IN ('SMB','Mid-Market','Enterprise')),
    country          VARCHAR(50),
    acquisition_date DATE,
    status           VARCHAR(20)  CHECK (status IN ('Active','Churned','Suspended')),
    created_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ────────────────────────────────────────────────────────────
-- DIM: Products
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dim_product (
    product_id      VARCHAR(20)    PRIMARY KEY,
    product_name    VARCHAR(100)   NOT NULL,
    subsidiary_id   VARCHAR(10)    REFERENCES dim_subsidiary(subsidiary_id),
    category        VARCHAR(50),
    unit_price      NUMERIC(12,2),
    is_recurring    BOOLEAN        DEFAULT FALSE,
    created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO dim_product VALUES
  ('PRD-CS-001', 'CloudBase Plan',       'SUB001', 'SaaS',       199,   TRUE,  NOW()),
  ('PRD-CS-002', 'CloudPro Plan',        'SUB001', 'SaaS',       499,   TRUE,  NOW()),
  ('PRD-CS-003', 'CloudEnterprise',      'SUB001', 'SaaS',      1299,   TRUE,  NOW()),
  ('PRD-CS-004', 'API Add-on',           'SUB001', 'Add-on',     149,   TRUE,  NOW()),
  ('PRD-RT-001', 'Storefront Starter',   'SUB002', 'Platform',   299,   TRUE,  NOW()),
  ('PRD-RT-002', 'Storefront Pro',       'SUB002', 'Platform',   799,   TRUE,  NOW()),
  ('PRD-RT-003', 'Analytics Suite',      'SUB002', 'Analytics',  399,   TRUE,  NOW()),
  ('PRD-RT-004', 'POS Integration',      'SUB002', 'Hardware',   599,  FALSE,  NOW()),
  ('PRD-AI-001', 'AI Audit',             'SUB003', 'Consulting', 3500,  FALSE, NOW()),
  ('PRD-AI-002', 'ML Pipeline Build',    'SUB003', 'Engineering',8500,  FALSE, NOW()),
  ('PRD-AI-003', 'Data Strategy',        'SUB003', 'Consulting', 5000,  FALSE, NOW()),
  ('PRD-AI-004', 'BI Implementation',    'SUB003', 'Engineering',7000,  FALSE, NOW());

-- ────────────────────────────────────────────────────────────
-- DIM: Chart of Accounts
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dim_account (
    account_code  VARCHAR(10)  PRIMARY KEY,
    account_name  VARCHAR(100) NOT NULL,
    account_type  VARCHAR(30)  CHECK (account_type IN ('Asset','Liability','Equity','Income','Expense')),
    account_group VARCHAR(50),
    is_active     BOOLEAN      DEFAULT TRUE
);

INSERT INTO dim_account VALUES
  ('1000', 'Cash & Equivalents',    'Asset',     'Current Assets',    TRUE),
  ('1100', 'Accounts Receivable',   'Asset',     'Current Assets',    TRUE),
  ('1200', 'Prepaid Expenses',      'Asset',     'Current Assets',    TRUE),
  ('1500', 'Fixed Assets (Net)',    'Asset',     'Non-Current Assets',TRUE),
  ('2000', 'Accounts Payable',      'Liability', 'Current Liabilities',TRUE),
  ('2100', 'Accrued Liabilities',   'Liability', 'Current Liabilities',TRUE),
  ('2500', 'Long-Term Debt',        'Liability', 'Long-Term Liabilities',TRUE),
  ('3000', 'Retained Earnings',     'Equity',    'Equity',            TRUE),
  ('3100', 'Common Stock',          'Equity',    'Equity',            TRUE),
  ('4000', 'Revenue',               'Income',    'Top-Line Revenue',  TRUE),
  ('4100', 'SaaS Revenue',          'Income',    'Recurring Revenue', TRUE),
  ('4200', 'Services Revenue',      'Income',    'Non-Recurring',     TRUE),
  ('5000', 'COGS',                  'Expense',   'Cost of Revenue',   TRUE),
  ('5100', 'Hosting & Infra',       'Expense',   'Cost of Revenue',   TRUE),
  ('5200', 'Direct Labor',          'Expense',   'Cost of Revenue',   TRUE),
  ('6000', 'Salaries & Wages',      'Expense',   'OpEx',              TRUE),
  ('6100', 'Marketing',             'Expense',   'OpEx',              TRUE),
  ('6200', 'R&D',                   'Expense',   'OpEx',              TRUE),
  ('6300', 'G&A',                   'Expense',   'OpEx',              TRUE),
  ('6400', 'Depreciation',          'Expense',   'Non-Cash',          TRUE),
  ('7000', 'Interest Expense',      'Expense',   'Below the Line',    TRUE);

-- ────────────────────────────────────────────────────────────
-- FACT: Transactions
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fact_transactions (
    transaction_id   VARCHAR(20)  PRIMARY KEY,
    txn_date         DATE         NOT NULL,
    month            SMALLINT,
    quarter          SMALLINT,
    year             SMALLINT,
    subsidiary_id    VARCHAR(10)  REFERENCES dim_subsidiary(subsidiary_id),
    customer_id      VARCHAR(15)  REFERENCES dim_customer(customer_id),
    product_id       VARCHAR(20)  REFERENCES dim_product(product_id),
    department       VARCHAR(50),
    quantity         INT,
    unit_price       NUMERIC(12,2),
    discount_rate    NUMERIC(5,4) DEFAULT 0,
    gross_amount     NUMERIC(14,2),
    net_amount       NUMERIC(14,2),
    currency         CHAR(3)      DEFAULT 'USD',
    payment_method   VARCHAR(30),
    status           VARCHAR(20),
    created_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ────────────────────────────────────────────────────────────
-- FACT: General Ledger
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fact_general_ledger (
    entry_id        VARCHAR(20)  PRIMARY KEY,
    journal_ref     VARCHAR(20),
    entry_date      DATE         NOT NULL,
    month           SMALLINT,
    quarter         SMALLINT,
    year            SMALLINT,
    subsidiary_id   VARCHAR(10)  REFERENCES dim_subsidiary(subsidiary_id),
    account_code    VARCHAR(10)  REFERENCES dim_account(account_code),
    debit_credit    CHAR(6)      CHECK (debit_credit IN ('Debit','Credit')),
    amount          NUMERIC(14,2),
    description     VARCHAR(200),
    department      VARCHAR(50),
    posted_by       VARCHAR(50),
    is_approved     BOOLEAN      DEFAULT FALSE,
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ────────────────────────────────────────────────────────────
-- INDEXES
-- ────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_txn_date      ON fact_transactions(txn_date);
CREATE INDEX IF NOT EXISTS idx_txn_sub       ON fact_transactions(subsidiary_id);
CREATE INDEX IF NOT EXISTS idx_txn_cust      ON fact_transactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_txn_status    ON fact_transactions(status);
CREATE INDEX IF NOT EXISTS idx_gl_date       ON fact_general_ledger(entry_date);
CREATE INDEX IF NOT EXISTS idx_gl_account    ON fact_general_ledger(account_code);
CREATE INDEX IF NOT EXISTS idx_gl_sub        ON fact_general_ledger(subsidiary_id);

-- ============================================================
-- ANALYTICS QUERIES
-- ============================================================

-- ─── Q1: Consolidated P&L Summary by Subsidiary ─────────────
SELECT
    s.subsidiary_name,
    SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END) AS total_revenue,
    SUM(CASE WHEN da.account_code = '5000'   AND gl.debit_credit = 'Debit'  THEN gl.amount ELSE 0 END) AS cogs,
    SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END)
    - SUM(CASE WHEN da.account_code = '5000' AND gl.debit_credit = 'Debit'  THEN gl.amount ELSE 0 END) AS gross_profit,
    ROUND(
        (SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END)
        - SUM(CASE WHEN da.account_code = '5000'  AND gl.debit_credit = 'Debit'  THEN gl.amount ELSE 0 END))
        / NULLIF(SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END), 0) * 100, 2
    ) AS gross_margin_pct
FROM fact_general_ledger gl
JOIN dim_subsidiary s    ON gl.subsidiary_id = s.subsidiary_id
JOIN dim_account    da   ON gl.account_code  = da.account_code
WHERE gl.year = 2024
GROUP BY s.subsidiary_name
ORDER BY total_revenue DESC;

-- ─── Q2: Monthly Revenue Trend ───────────────────────────────
SELECT
    gl.year,
    gl.month,
    TO_CHAR(DATE_TRUNC('month', gl.entry_date), 'Mon YYYY') AS period,
    SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END) AS total_revenue,
    LAG(SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END))
        OVER (ORDER BY gl.year, gl.month) AS prior_month_revenue,
    ROUND(
        (SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END)
        - LAG(SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END))
            OVER (ORDER BY gl.year, gl.month))
        / NULLIF(LAG(SUM(CASE WHEN da.account_type = 'Income' AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END))
            OVER (ORDER BY gl.year, gl.month), 0) * 100, 2
    ) AS mom_growth_pct
FROM fact_general_ledger gl
JOIN dim_account da ON gl.account_code = da.account_code
WHERE gl.year = 2024
GROUP BY gl.year, gl.month, DATE_TRUNC('month', gl.entry_date)
ORDER BY gl.month;

-- ─── Q3: EBITDA Calculation by Subsidiary ────────────────────
WITH revenue AS (
    SELECT subsidiary_id,
           SUM(amount) AS total_revenue
    FROM fact_general_ledger
    WHERE year = 2024
      AND account_code = '4000'
      AND debit_credit = 'Credit'
    GROUP BY subsidiary_id
),
opex AS (
    SELECT subsidiary_id,
           SUM(CASE WHEN account_code IN ('5000','6000','6100','6200','6300') AND debit_credit = 'Debit' THEN amount ELSE 0 END) AS total_opex,
           SUM(CASE WHEN account_code = '6400' AND debit_credit = 'Debit' THEN amount ELSE 0 END) AS da
    FROM fact_general_ledger
    WHERE year = 2024
    GROUP BY subsidiary_id
)
SELECT
    s.subsidiary_name,
    r.total_revenue,
    o.total_opex,
    r.total_revenue - o.total_opex + o.da AS ebitda,
    ROUND((r.total_revenue - o.total_opex + o.da) / NULLIF(r.total_revenue, 0) * 100, 2) AS ebitda_margin_pct
FROM revenue r
JOIN opex o         ON r.subsidiary_id = o.subsidiary_id
JOIN dim_subsidiary s ON r.subsidiary_id = s.subsidiary_id
ORDER BY ebitda DESC;

-- ─── Q4: Top 10 Customers by Revenue ─────────────────────────
SELECT
    c.customer_id,
    c.customer_name,
    c.segment,
    s.subsidiary_name,
    COUNT(DISTINCT t.transaction_id) AS total_transactions,
    SUM(t.net_amount)                AS total_revenue,
    AVG(t.net_amount)                AS avg_transaction_value,
    MAX(t.txn_date)                  AS last_transaction_date
FROM fact_transactions t
JOIN dim_customer   c ON t.customer_id   = c.customer_id
JOIN dim_subsidiary s ON t.subsidiary_id = s.subsidiary_id
WHERE t.year = 2024
  AND t.status = 'Completed'
GROUP BY c.customer_id, c.customer_name, c.segment, s.subsidiary_name
ORDER BY total_revenue DESC
LIMIT 10;

-- ─── Q5: Revenue by Product ───────────────────────────────────
SELECT
    p.product_id,
    p.product_name,
    s.subsidiary_name,
    p.category,
    COUNT(t.transaction_id)  AS units_sold,
    SUM(t.net_amount)        AS total_revenue,
    AVG(t.discount_rate)*100 AS avg_discount_pct,
    SUM(t.net_amount) / NULLIF(SUM(SUM(t.net_amount)) OVER (), 0) * 100 AS revenue_share_pct
FROM fact_transactions t
JOIN dim_product    p ON t.product_id    = p.product_id
JOIN dim_subsidiary s ON t.subsidiary_id = s.subsidiary_id
WHERE t.year = 2024 AND t.status = 'Completed'
GROUP BY p.product_id, p.product_name, s.subsidiary_name, p.category
ORDER BY total_revenue DESC;

-- ─── Q6: Quarterly P&L Bridge ────────────────────────────────
SELECT
    gl.quarter,
    s.subsidiary_name,
    SUM(CASE WHEN da.account_type = 'Income'  AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END) AS revenue,
    SUM(CASE WHEN da.account_type = 'Expense' AND gl.debit_credit = 'Debit'  THEN gl.amount ELSE 0 END) AS total_expenses,
    SUM(CASE WHEN da.account_type = 'Income'  AND gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END)
    - SUM(CASE WHEN da.account_type = 'Expense' AND gl.debit_credit = 'Debit' THEN gl.amount ELSE 0 END) AS net_income
FROM fact_general_ledger gl
JOIN dim_subsidiary s ON gl.subsidiary_id = s.subsidiary_id
JOIN dim_account   da ON gl.account_code  = da.account_code
WHERE gl.year = 2024
GROUP BY gl.quarter, s.subsidiary_name
ORDER BY gl.quarter, s.subsidiary_name;

-- ─── Q7: Customer Churn Analysis ─────────────────────────────
SELECT
    s.subsidiary_name,
    c.segment,
    COUNT(CASE WHEN c.status = 'Active'  THEN 1 END)  AS active_customers,
    COUNT(CASE WHEN c.status = 'Churned' THEN 1 END)  AS churned_customers,
    COUNT(*)                                            AS total_customers,
    ROUND(COUNT(CASE WHEN c.status = 'Churned' THEN 1 END)::NUMERIC / NULLIF(COUNT(*),0) * 100, 2) AS churn_rate_pct
FROM dim_customer c
JOIN dim_subsidiary s ON c.subsidiary_id = s.subsidiary_id
GROUP BY s.subsidiary_name, c.segment
ORDER BY s.subsidiary_name, c.segment;

-- ─── Q8: Departmental Expense Breakdown ──────────────────────
SELECT
    t.department,
    COUNT(t.transaction_id)                           AS transactions,
    SUM(t.net_amount)                                 AS total_spend,
    ROUND(AVG(t.net_amount), 2)                       AS avg_transaction,
    SUM(t.net_amount) / SUM(SUM(t.net_amount)) OVER () * 100 AS spend_share_pct
FROM fact_transactions t
WHERE t.year = 2024
GROUP BY t.department
ORDER BY total_spend DESC;

-- ─── VIEW: P&L Dashboard View ────────────────────────────────
CREATE OR REPLACE VIEW vw_pl_dashboard AS
SELECT
    s.subsidiary_name,
    gl.year,
    gl.quarter,
    gl.month,
    da.account_type,
    da.account_group,
    da.account_name,
    SUM(CASE WHEN gl.debit_credit = 'Debit'  THEN gl.amount ELSE 0 END) AS debit_total,
    SUM(CASE WHEN gl.debit_credit = 'Credit' THEN gl.amount ELSE 0 END) AS credit_total,
    SUM(CASE WHEN gl.debit_credit = 'Credit' THEN gl.amount
             WHEN gl.debit_credit = 'Debit'  THEN -gl.amount ELSE 0 END) AS net_balance
FROM fact_general_ledger gl
JOIN dim_subsidiary s ON gl.subsidiary_id = s.subsidiary_id
JOIN dim_account   da ON gl.account_code  = da.account_code
GROUP BY s.subsidiary_name, gl.year, gl.quarter, gl.month,
         da.account_type, da.account_group, da.account_name;

-- ─── VIEW: KPI Summary View ──────────────────────────────────
CREATE OR REPLACE VIEW vw_kpi_summary AS
WITH rev_base AS (
    SELECT subsidiary_id, SUM(amount) AS total_rev
    FROM fact_general_ledger
    WHERE year = 2024 AND account_type = 'Income' -- simplified
    GROUP BY subsidiary_id
)
SELECT
    s.subsidiary_name,
    rb.total_rev AS fy2024_revenue,
    ROUND(rb.total_rev / 12, 0) AS implied_mrr,
    ROUND(rb.total_rev,       0) AS implied_arr
FROM rev_base rb
JOIN dim_subsidiary s ON rb.subsidiary_id = s.subsidiary_id;

-- ============================================================
-- END OF PLCA1 SQL SCRIPT
-- ============================================================
