# 📊 P.L.C.A 1 — Profit & Loss Consolidated Analysis

<div align="center">

![Banner](docs/banner.svg)

[![Author](https://img.shields.io/badge/Author-CHIKEB%20ANAS-1E88E5?style=for-the-badge&logo=github)](https://github.com/chikeb-anas)
[![Level](https://img.shields.io/badge/Level-Advanced%20%7C%20Level%203-00C9A7?style=for-the-badge)]()
[![Stack](https://img.shields.io/badge/Stack-SQL%20%7C%20Python%20%7C%20Excel%20%7C%20HTML-F5A623?style=for-the-badge)]()
[![Status](https://img.shields.io/badge/Status-Complete-43A047?style=for-the-badge)]()
[![License](https://img.shields.io/badge/License-MIT-white?style=for-the-badge)](LICENSE)

**Enterprise-level financial analytics project simulating a multi-subsidiary holding group.**  
Full P&L consolidation · 2,785 transactions · 7 deliverable files · FY2024

</div>

---

## 🏢 Company Simulated

**NexaGroup Holdings Ltd.** — A fictional multi-entity holding group operating 3 subsidiaries:

| Entity | Industry | FY2024 Revenue | YoY Growth |
|--------|----------|----------------|------------|
| NexaCloud SaaS | Software / SaaS | $2,523,000 | +16.8% |
| NexaRetail Pro | E-Commerce | $1,408,500 | +10.0% |
| NexaAI Solutions | AI Consulting | $1,413,000 | +53.6% 🚀 |
| **NexaGroup (Consolidated)** | **Holding Group** | **$4,740,000** | **+17.3%** |

---

## 📁 Repository Structure

```
PLCA1/
│
├── 📂 data/
│   ├── transactions.csv          # 2,785 FY2024 transactions
│   ├── general_ledger.csv        # 504 journal entries
│   └── customers.csv             # 120 customers (3 segments)
│
├── 📂 sql/
│   └── PLCA1_schema_and_queries.sql  # PostgreSQL schema + 8 analytics queries
│
├── 📂 reports/
│   ├── PLCA1_Financial_Model.xlsx    # 6-sheet Excel financial model
│   ├── PLCA1_Dashboard.html          # Interactive 5-page HTML dashboard
│   └── PLCA1_LinkedIn_Post.txt       # LinkedIn publication post
│
├── 📂 scripts/
│   ├── generate_data.py          # Synthetic data generator
│   └── generate_excel.py         # Excel model builder
│
├── 📂 docs/
│   ├── DATA_DICTIONARY.md        # Full data dictionary
│   ├── KPI_DEFINITIONS.md        # All KPI formulas explained
│   └── ARCHITECTURE.md           # Technical architecture overview
│
├── README.md
├── requirements.txt
├── .gitignore
└── LICENSE
```

---

## 💰 Key Financial Results — FY2024

### Income Statement (Consolidated)

| Metric | FY2024 | Margin | YoY |
|--------|--------|--------|-----|
| Gross Revenue | $4,740,000 | 100% | +17.3% |
| Net Revenue | $5,205,338 | 100% | +16.8% |
| Gross Profit | $3,800,126 | 73.0% | +18.1% |
| EBITDA | $877,276 | 19.4% | +22.5% |
| EBIT | $721,116 | 13.9% | — |
| Net Income | $508,000 | 9.8% | +19.7% |

### SaaS KPIs (NexaCloud)

| KPI | Value | YoY |
|-----|-------|-----|
| ARR | $2,523,000 | +16.8% |
| MRR | $210,250 | +16.8% |
| Net Revenue Retention | 118% | +3pp |
| Churn Rate | 4.2% | -1.1pp |
| CAC | $342 | -8.2% |
| LTV | $8,190 | +12.4% |
| LTV:CAC | 23.9x | +22.6% |

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| **Data Generation** | Python · Faker · Random |
| **Data Storage** | CSV · PostgreSQL |
| **Financial Model** | Excel (openpyxl) |
| **Dashboard** | HTML · CSS · SVG (no BI tool) |
| **Database** | PostgreSQL 15+ |
| **ETL / Scripting** | Python 3.11 |

---

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/chikeb-anas/PLCA1-financial-analysis.git
cd PLCA1-financial-analysis
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Generate Data

```bash
python scripts/generate_data.py
```

### 4. Build Excel Model

```bash
python scripts/generate_excel.py
```

### 5. Load into PostgreSQL

```bash
psql -U postgres -d your_db -f sql/PLCA1_schema_and_queries.sql
```

### 6. Open Dashboard

```bash
open reports/PLCA1_Dashboard.html
# or simply open the file in your browser
```

---

## 📊 Dashboard Preview

The interactive HTML dashboard contains **5 pages**:

| Page | Content |
|------|---------|
| Overview | KPI cards · Revenue chart · Margin analysis |
| P&L Statement | Full consolidated income statement |
| Subsidiaries | Individual subsidiary deep-dives |
| KPI Dashboard | 30+ financial, SaaS & marketing KPIs |
| Cash Flow | H1/H2/FY operating · investing · financing |

> Open `reports/PLCA1_Dashboard.html` in any browser — no server required.

---

## 🗄 Database Schema

The PostgreSQL schema follows a **star schema** pattern:

```
fact_transactions ──── dim_subsidiary
fact_transactions ──── dim_customer
fact_transactions ──── dim_product
fact_general_ledger ── dim_subsidiary
fact_general_ledger ── dim_account
```

**Included SQL Analytics:**
- Q1: Consolidated P&L by Subsidiary
- Q2: Monthly Revenue Trend with MoM Growth
- Q3: EBITDA Calculation by Subsidiary
- Q4: Top 10 Customers by Revenue
- Q5: Revenue by Product with Share %
- Q6: Quarterly P&L Bridge
- Q7: Customer Churn Analysis
- Q8: Departmental Expense Breakdown

---

## 📂 Data Overview

| File | Rows | Key Fields |
|------|------|------------|
| `transactions.csv` | 2,785 | date, subsidiary, customer, product, amount, status |
| `general_ledger.csv` | 504 | entry_id, account_code, debit/credit, amount |
| `customers.csv` | 120 | customer_id, segment, country, status |

---

## 📈 Excel Model — 6 Sheets

| Sheet | Description |
|-------|-------------|
| 📋 Cover | Project metadata & table of contents |
| 📊 P&L Summary | Consolidated income statement by subsidiary |
| 📅 Monthly P&L | Month-by-month revenue & expense breakdown |
| 📈 KPI Dashboard | 40+ KPIs (Financial · SaaS · Marketing) |
| 💰 Cash Flow | Operating · Investing · Financing activities |
| 📋 General Ledger | GL summary by account and quarter |

---

## 🏗 Next in the Series

This is **P.L.C.A 1** — the first in a series of financial analytics projects:

| Project | Topic | Status |
|---------|-------|--------|
| **P.L.C.A 1** | P&L Consolidated Analysis | ✅ Complete |
| P.L.C.A 2 | Budget vs Actuals + Forecasting | 🔜 Coming |
| P.L.C.A 3 | Cash Flow Modeling + Treasury | 🔜 Coming |
| P.L.C.A 4 | Azure Data Pipeline + Lakehouse | 🔜 Coming |
| P.L.C.A 5 | AI-Powered Financial Analysis | 🔜 Coming |

---

## 📄 License

This project is licensed under the **MIT License** — see [LICENSE](LICENSE) for details.

---

## ✍️ Author

<div align="center">

```
╔══════════════════════════════════════════════════╗
║                                                  ║
║            CHIKEB ANAS                           ║
║                                                  ║
║   Senior Data Analyst · BI Consultant            ║
║   Financial Analytics · Data Engineering         ║
║                                                  ║
║   SQL · Python · Power BI · Excel · Azure        ║
║                                                  ║
╚══════════════════════════════════════════════════╝
```

[![GitHub](https://img.shields.io/badge/GitHub-chikeb--anas-181717?style=flat-square&logo=github)](https://github.com/chikeb-anas)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-CHIKEB%20ANAS-0A66C2?style=flat-square&logo=linkedin)](https://linkedin.com/in/chikeb-anas)

> *"Data tells a story. Financial data tells the truth."*  
> — CHIKEB ANAS

</div>

---

<div align="center">

**P.L.C.A 1** · NexaGroup Holdings Ltd. · FY2024  
Made with precision by **CHIKEB ANAS**

</div>
