# KPI Definitions — P.L.C.A 1
**Author: CHIKEB ANAS**  
**Project: NexaGroup Holdings Ltd. | FY2024**

---

## 💰 Financial KPIs

### Revenue Metrics

| KPI | Formula | FY2024 | Notes |
|-----|---------|--------|-------|
| **Gross Revenue** | Sum of all billed amounts | $4,740,000 | Before discounts |
| **Net Revenue** | Gross Revenue – Discounts – Returns | $5,205,338 | Top-line P&L |
| **Revenue Growth** | (Current – Prior) / Prior × 100 | +17.3% | YoY |

### Profitability Metrics

| KPI | Formula | FY2024 | Notes |
|-----|---------|--------|-------|
| **Gross Profit** | Net Revenue – COGS | $3,800,126 | |
| **Gross Margin %** | Gross Profit / Net Revenue × 100 | 73.0% | Industry benchmark: 65–75% for SaaS |
| **EBITDA** | Gross Profit – OpEx + D&A | $877,276 | Earnings Before Interest, Taxes, D&A |
| **EBITDA Margin %** | EBITDA / Net Revenue × 100 | 19.4% | |
| **EBIT** | EBITDA – D&A | $721,116 | Operating Income |
| **EBIT Margin %** | EBIT / Net Revenue × 100 | 13.9% | |
| **EBT** | EBIT – Interest Expense | $643,036 | Earnings Before Tax |
| **Net Income** | EBT – Income Tax | $508,000 | Bottom line |
| **Net Margin %** | Net Income / Net Revenue × 100 | 9.8% | |

### Balance Sheet Ratios

| KPI | Formula | FY2024 |
|-----|---------|--------|
| **Current Ratio** | Current Assets / Current Liabilities | 2.4x |
| **Cash Ratio** | Cash / Current Liabilities | 1.8x |
| **Debt-to-Equity** | Total Debt / Total Equity | 0.42 |
| **ROA** | Net Income / Total Assets × 100 | 14.2% |
| **ROE** | Net Income / Total Equity × 100 | 22.7% |

---

## 📊 SaaS KPIs (NexaCloud)

| KPI | Formula | FY2024 | Notes |
|-----|---------|--------|-------|
| **ARR** | MRR × 12 | $2,523,000 | Annual Recurring Revenue |
| **MRR** | Sum of monthly subscription revenue | $210,250 | Monthly Recurring Revenue |
| **NRR** | (Beginning MRR + Expansion – Contraction – Churn) / Beginning MRR | 118% | Net Revenue Retention. >100% = growth without new customers |
| **Churn Rate** | Churned Customers / Total Customers (start of period) | 4.2% | Annual |
| **CAC** | Total Sales & Marketing Spend / New Customers Acquired | $342 | Customer Acquisition Cost |
| **LTV** | ARPU × Gross Margin % / Churn Rate | $8,190 | Customer Lifetime Value |
| **LTV:CAC** | LTV / CAC | 23.9x | World-class: >3x. >20x = exceptional |
| **Payback Period** | CAC / (ARPU × Gross Margin %) | ~14 months | Months to recover CAC |
| **ARPU** | Total Revenue / Active Customers | $886/month | Average Revenue Per User |

---

## 📣 Marketing KPIs

| KPI | Formula | FY2024 |
|-----|---------|--------|
| **Marketing ROI** | (Revenue from Marketing – Marketing Spend) / Marketing Spend | 8.56x |
| **Lead-to-Close Rate** | Closed Deals / Total Leads | 22.4% |
| **Demo Conversion Rate** | Demos to Paid / Total Demos | 18.3% |
| **Blended CAC** | Total Marketing + Sales / All New Customers | $342 |
| **New Customers** | Count of customers acquired in period | 1,452 |

---

## 📦 Operational KPIs

| KPI | Formula | FY2024 |
|-----|---------|--------|
| **Revenue per Employee** | Total Revenue / Total Headcount | $27,706 |
| **Total Transactions** | Count of completed transactions | 2,785 |
| **Avg Transaction Value** | Net Revenue / Transaction Count | $1,870 |
| **Discount Rate (avg)** | Avg discount applied across all transactions | 4.3% |

---

## 🏢 Subsidiary KPIs

| Subsidiary | Revenue | EBITDA Margin | Growth | Headcount |
|------------|---------|---------------|--------|-----------|
| NexaCloud SaaS | $2,523,000 | 21.3% | +16.8% | 87 |
| NexaRetail Pro | $1,408,500 | 17.1% | +10.0% | 52 |
| NexaAI Solutions | $1,413,000 | 24.8% | +53.6% | 34 |

---

## 📐 KPI Benchmarks Reference

| Metric | Good | World-Class | P.L.C.A 1 |
|--------|------|-------------|-----------|
| Gross Margin (SaaS) | >65% | >75% | 73.0% ✅ |
| EBITDA Margin | >15% | >25% | 19.4% ✅ |
| NRR | >100% | >120% | 118% ✅ |
| Churn Rate | <5% | <2% | 4.2% ✅ |
| LTV:CAC | >3x | >20x | 23.9x ✅ |
| CAC Payback | <18mo | <12mo | ~14mo ✅ |

---

*Author: CHIKEB ANAS | P.L.C.A 1 | NexaGroup Holdings | FY2024*
