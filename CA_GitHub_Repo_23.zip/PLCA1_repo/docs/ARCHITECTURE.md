# Technical Architecture — P.L.C.A 1
**Author: CHIKEB ANAS**  
**Project: NexaGroup Holdings Ltd. | FY2024**

---

## Overview

P.L.C.A 1 follows a **3-layer architecture**: Data Engineering → Financial Modeling → Reporting.

```
┌─────────────────────────────────────────────────────────────┐
│                    DATA GENERATION LAYER                    │
│                                                             │
│   Python scripts → CSV files → PostgreSQL (Star Schema)    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                  FINANCIAL MODELING LAYER                   │
│                                                             │
│   P&L · Cash Flow · GL Summary · KPI Engine (Excel)        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    REPORTING LAYER                          │
│                                                             │
│   HTML Dashboard · LinkedIn Post · SVG Summary Image       │
└─────────────────────────────────────────────────────────────┘
```

---

## Data Model — Star Schema

```
                    ┌──────────────────┐
                    │  dim_subsidiary  │
                    │  subsidiary_id   │
                    │  name, category  │
                    └────────┬─────────┘
                             │
          ┌──────────────────┼──────────────────┐
          │                  │                  │
          ▼                  ▼                  ▼
┌──────────────────┐ ┌────────────────┐ ┌──────────────────┐
│  dim_customer    │ │ fact_txns      │ │ fact_gl          │
│  customer_id     │ │ transaction_id │ │ entry_id         │
│  name, segment   │ │ date, amount   │ │ account_code     │
│  country, status │ │ customer_id FK │ │ debit_credit     │
└──────────────────┘ │ product_id FK  │ │ amount           │
                     │ subsidiary FK  │ └──────────────────┘
          ┌──────────┘                └──────┐
          ▼                                  ▼
┌──────────────────┐                ┌──────────────────┐
│  dim_product     │                │  dim_account     │
│  product_id      │                │  account_code    │
│  name, price     │                │  name, type      │
│  is_recurring    │                │  account_group   │
└──────────────────┘                └──────────────────┘
```

---

## File Pipeline

```
generate_data.py
    ├── → data/customers.csv         (120 rows)
    ├── → data/transactions.csv      (2,785 rows)
    └── → data/general_ledger.csv    (504 rows)

generate_excel.py
    ├── reads: data/*.csv
    └── → reports/PLCA1_Financial_Model.xlsx
           ├── Sheet: 📋 Cover
           ├── Sheet: 📊 P&L Summary
           ├── Sheet: 📅 Monthly P&L
           ├── Sheet: 📈 KPI Dashboard
           ├── Sheet: 💰 Cash Flow
           └── Sheet: 📋 General Ledger

sql/PLCA1_schema_and_queries.sql
    ├── CREATE SCHEMA nexagroup
    ├── CREATE TABLE dim_subsidiary
    ├── CREATE TABLE dim_customer
    ├── CREATE TABLE dim_product
    ├── CREATE TABLE dim_account
    ├── CREATE TABLE fact_transactions
    ├── CREATE TABLE fact_general_ledger
    ├── CREATE INDEX (6 indexes)
    ├── Analytics Query Q1–Q8
    ├── VIEW vw_pl_dashboard
    └── VIEW vw_kpi_summary

reports/PLCA1_Dashboard.html
    ├── Page 1: Overview
    ├── Page 2: P&L Statement
    ├── Page 3: Subsidiaries
    ├── Page 4: KPI Dashboard
    └── Page 5: Cash Flow
```

---

## Technology Decisions

### Why PostgreSQL?
- Native window functions (LAG, OVER, PARTITION BY) for YoY analysis
- CTE support for multi-step financial calculations
- NUMERIC type for exact financial arithmetic

### Why openpyxl over pandas for Excel?
- Cell-level formula support (=SUM, =AVERAGE) rather than hardcoded values
- Rich formatting (colors, borders, fonts) for professional output
- Named ranges and chart embedding

### Why Pure HTML Dashboard (no Power BI / Tableau)?
- Zero licensing cost
- Works offline — open in any browser
- Fully portable as a single `.html` file
- Can be embedded in any web page or GitHub Pages

---

## Extending the Project

### Add Azure Data Factory
```
Azure Blob Storage (CSV) 
    → ADF Pipeline 
    → Azure SQL Database 
    → Power BI Dataset 
    → Published Dashboard
```

### Add Microsoft Fabric / Lakehouse
```
Raw CSV (Bronze Layer)
    → Delta Tables (Silver Layer) 
    → Aggregated Finance Tables (Gold Layer)
    → Semantic Model
    → Power BI Report
```

### Add Python Forecasting
```python
from prophet import Prophet

# Forecast next 12 months of revenue
model = Prophet(yearly_seasonality=True)
model.fit(monthly_revenue_df)
future = model.make_future_dataframe(periods=12, freq='MS')
forecast = model.predict(future)
```

---

*Author: CHIKEB ANAS | P.L.C.A 1 | NexaGroup Holdings | FY2024*
