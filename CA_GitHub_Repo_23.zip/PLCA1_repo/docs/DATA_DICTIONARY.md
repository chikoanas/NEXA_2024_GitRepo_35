# Data Dictionary — P.L.C.A 1
**Author: CHIKEB ANAS**  
**Project: NexaGroup Holdings Ltd. | FY2024**

---

## Table: `fact_transactions`

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| transaction_id | VARCHAR(20) | Unique transaction identifier | TXN-000001 |
| date | DATE | Transaction date | 2024-01-15 |
| month | SMALLINT | Month number (1–12) | 1 |
| quarter | SMALLINT | Quarter (1–4) | 1 |
| year | SMALLINT | Fiscal year | 2024 |
| subsidiary_id | VARCHAR(10) | FK to dim_subsidiary | SUB001 |
| subsidiary_name | VARCHAR(100) | Subsidiary full name | NexaCloud SaaS |
| customer_id | VARCHAR(15) | FK to dim_customer | CUS-0001 |
| product_id | VARCHAR(20) | FK to dim_product | PRD-CS-001 |
| product_name | VARCHAR(100) | Product display name | CloudBase Plan |
| category | VARCHAR(50) | Business category | SaaS |
| department | VARCHAR(50) | Originating department | Sales |
| quantity | INT | Units purchased | 2 |
| unit_price | NUMERIC(12,2) | Price per unit (USD) | 199.00 |
| discount_rate | NUMERIC(5,4) | Applied discount (0–1) | 0.10 |
| gross_amount | NUMERIC(14,2) | Revenue before discount | 398.00 |
| net_amount | NUMERIC(14,2) | Revenue after discount | 358.20 |
| currency | CHAR(3) | ISO currency code | USD |
| payment_method | VARCHAR(30) | Card / Wire / ACH / Invoice | Card |
| status | VARCHAR(20) | Completed / Pending / Refunded | Completed |

---

## Table: `fact_general_ledger`

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| entry_id | VARCHAR(20) | Unique GL entry ID | GL-000001 |
| journal_ref | VARCHAR(20) | Journal entry reference | JE-00001 |
| entry_date | DATE | Posting date | 2024-01-28 |
| month | SMALLINT | Month number | 1 |
| quarter | SMALLINT | Quarter number | 1 |
| year | SMALLINT | Fiscal year | 2024 |
| subsidiary_id | VARCHAR(10) | FK to dim_subsidiary | SUB001 |
| account_code | VARCHAR(10) | FK to dim_account | 4000 |
| debit_credit | CHAR(6) | Debit or Credit side | Credit |
| amount | NUMERIC(14,2) | Entry amount (USD) | 195000.00 |
| description | VARCHAR(200) | Entry description | Monthly Revenue Recognition |
| department | VARCHAR(50) | Department | Finance |
| posted_by | VARCHAR(50) | User who posted entry | jsmith |
| is_approved | BOOLEAN | Approval status | true |

---

## Table: `dim_subsidiary`

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| subsidiary_id | VARCHAR(10) | PK — unique subsidiary code | SUB001 |
| subsidiary_name | VARCHAR(100) | Full legal name | NexaCloud SaaS |
| category | VARCHAR(50) | Business category | SaaS |
| currency | CHAR(3) | Functional currency | USD |
| country | VARCHAR(50) | Country of incorporation | USA |
| founded_year | INT | Year established | 2019 |
| headcount | INT | Full-time employees | 87 |

---

## Table: `dim_customer`

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| customer_id | VARCHAR(15) | PK — unique customer code | CUS-0001 |
| customer_name | VARCHAR(150) | Customer company name | Apex Corp 1 |
| subsidiary_id | VARCHAR(10) | FK to dim_subsidiary | SUB001 |
| segment | VARCHAR(30) | SMB / Mid-Market / Enterprise | Enterprise |
| country | VARCHAR(50) | Customer country | USA |
| acquisition_date | DATE | When customer was acquired | 2022-03-14 |
| status | VARCHAR(20) | Active / Churned / Suspended | Active |

---

## Table: `dim_product`

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| product_id | VARCHAR(20) | PK — unique product code | PRD-CS-001 |
| product_name | VARCHAR(100) | Product display name | CloudBase Plan |
| subsidiary_id | VARCHAR(10) | FK to dim_subsidiary | SUB001 |
| category | VARCHAR(50) | Product category | SaaS |
| unit_price | NUMERIC(12,2) | List price (USD) | 199.00 |
| is_recurring | BOOLEAN | Subscription vs one-time | true |

---

## Table: `dim_account`

| Column | Type | Description | Values |
|--------|------|-------------|--------|
| account_code | VARCHAR(10) | PK — COA account number | 4000 |
| account_name | VARCHAR(100) | Account name | Revenue |
| account_type | VARCHAR(30) | Account classification | Asset / Liability / Equity / Income / Expense |
| account_group | VARCHAR(50) | Account grouping | Top-Line Revenue |
| is_active | BOOLEAN | Active in current period | true |

---

## Chart of Accounts Reference

| Code | Name | Type | Group |
|------|------|------|-------|
| 1000 | Cash & Equivalents | Asset | Current Assets |
| 1100 | Accounts Receivable | Asset | Current Assets |
| 2000 | Accounts Payable | Liability | Current Liabilities |
| 2500 | Long-Term Debt | Liability | Long-Term Liabilities |
| 3000 | Retained Earnings | Equity | Equity |
| 4000 | Revenue | Income | Top-Line Revenue |
| 4100 | SaaS Revenue | Income | Recurring Revenue |
| 4200 | Services Revenue | Income | Non-Recurring |
| 5000 | COGS | Expense | Cost of Revenue |
| 6000 | Salaries & Wages | Expense | OpEx |
| 6100 | Marketing | Expense | OpEx |
| 6200 | R&D | Expense | OpEx |
| 6300 | G&A | Expense | OpEx |
| 6400 | Depreciation | Expense | Non-Cash |
| 7000 | Interest Expense | Expense | Below the Line |

---

*Author: CHIKEB ANAS | P.L.C.A 1 | NexaGroup Holdings | FY2024*
